
<ui-description <?php echo e($attributes->class('text-sm text-zinc-500 dark:text-white/60')); ?> data-flux-description>
    <?php echo e($slot); ?>

</ui-description>
<?php /**PATH D:\projects\Duplay-Absense\vendor\livewire\flux\stubs\resources\views\flux\description.blade.php ENDPATH**/ ?>