<footer class="w-full p-4 bg-gradient-to-r from-indigo-600 to-indigo-500 text-white text-center text-sm shadow-inner">
    &copy; <?php echo e(date('Y')); ?> SMA Negeri 2 Playen
</footer>
<?php /**PATH D:\projects\Duplay-Absense\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>