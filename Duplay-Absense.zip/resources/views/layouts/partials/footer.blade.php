<footer class="w-full p-4 bg-gradient-to-r from-indigo-600 to-indigo-500 text-white text-center text-sm shadow-inner">
    &copy; {{ date('Y') }} SMA Negeri 2 Playen
</footer>
